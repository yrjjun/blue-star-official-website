<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>网站总览</title>
    <?php
    require("../../config.php");
    $conn = mysqli_connect($host, $user, $password, $dbname);
    require("../../function.php");
    $user_info = $bluestar->detection($conn);
    $isadmin = strpos($user_info["status"], "admin") !== false;
    if (!$isadmin) {
        $bluestar->add_log($conn, "无权限访问admin面板", "", $_SERVER['REMOTE_ADDR'], time(), "200");
        header('Location: ../');
        exit;
    }
    require("../../config.php");
    require("../../function.php");
    $info=$bluestar->get_website_info($conn);
    echo "一小时访问量：".$info["times"]."次<br>";
    echo "用户数：".$info["user"]."个<br>";
    ?>
</head>
<body>
    
</body>
</html>