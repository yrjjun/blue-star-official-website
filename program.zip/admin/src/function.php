<script src="../../file/js/function.js"></script>
<script src="../../file/js/jq.js"></script>
<?php
    require("../../config.php");
    $conn = mysqli_connect($host, $user, $password, $dbname);
    require("../../function.php");
    $user_info = $bluestar->detection($conn);
    $isadmin = strpos($user_info["status"], "admin") !== false;
    if (!$isadmin) {
        $bluestar->add_log($conn, "无权限访问admin面板", "", $_SERVER['REMOTE_ADDR'], time(), "200");
        header('Location: ../');
        exit;
    }
    if(isset($_GET["id"])){
        $status = $_GET["status"];
        mysqli_query($conn,"UPDATE `blue_function` SET status='$statue' WHERE id='".$_GET["id"]."'");
    }
    foreach ($bluestar->get_function($conn) as $things) {
        $name = $things["name"];
        $id = $things["id"];
        $status=$things["status"];
        if($status==1){
            $aaa=0;
            $text="关闭";
        }else{
            $aaa=1;
            $text="开启";
        }
        echo <<<_
        <p>id：$id  功能名：$name</p>
        <button onclick="button('$id','$aaa')">$text</button>
        _;
        
        
    }
?>