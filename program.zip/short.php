<?php
require("./config.php");
require("./function.php");
$bluestar->get_function(mysqli_connect($host, $user, $password, $dbname),1);
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 获取短码参数
if (isset($_GET['shortcode'])) {
    $shortcode = $_GET['shortcode'];

    // 查询数据库获取长链接
    $sql = "SELECT url FROM urls WHERE shortcode = '$shortcode'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // 找到匹配的短码，进行重定向
        $row = $result->fetch_assoc();
        $longUrl = $row['url'];
        header("Location: " . $longUrl);
        exit;
    } else {
        // 未找到匹配的短码
        echo "无效的短码";
    }
} else {
    // 缺少短码参数
    echo "缺少短码参数";
}

// 关闭数据库连接
$conn->close();
?>
