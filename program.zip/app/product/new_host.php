<?php
$request_new_host = array(
    "username"=>"",
    "userkey"=>"",
    "apiip"=>"",
    "hostname"=>"主机账户用户名",
    "hostpwd"=>"账户密码",
    "hostdomain"=>"域名",
    "hostlimit"=>"空间大小",
    "dblimit"=>"数据库大小",
    "domainlimit"=>"域名数",
    "dirlimit"=>"子目录数",
    "flowlimit"=>"流量",
    "hosttype"=>"0：虚拟主机；1：cdn",
    "port"=>"端口",
    "web_back_num"=>"10",
    "sql_back_num"=>"10",
    "subairflag"=>"是否允许子目录"
);

?>