<?php
setcookie("user_email","0");
setcookie("user_password","0");
?>