<?php
$bluestar->get_function($conn,8);
    $to=preg_replace("/[^A-Za-z0-9.@]/", "", $_REQUEST["email"]);
    $result = mysqli_query($conn,"SELECT * FROM blue_code WHERE email='$to' AND code='0'");
    if($result->num_rows ==0){
        $return = array('info'=>"请点击“发送验证码”".$id, 'code'=>401);
        echo json_encode($return);
    }else{
        while($row = mysqli_fetch_array($result)){
        if ($row["time"]+60*5<time()){
            $return = array('info'=>"当前验证码已超时", 'code'=>402);
            echo json_encode($return);
        }else{
            if($row["text"]==$_REQUEST["text"]){
                $user = mysqli_query($conn,"SELECT * FROM blue_user WHERE email='$to'");
                if($user->num_rows ==0){//不存在该账户
                    $return = array('info'=>"注册成功", 'code'=>200);
                    $password = hash("sha256", $_REQUEST["password"]);
                    $token = hash("sha256", $to.$password.time());
                    $ip = $_SERVER['REMOTE_ADDR'];
                    $time = time();
                    mysqli_query($conn, "DELETE FROM `blue_code` WHERE email='$to'");
                    mysqli_query($conn, "INSERT INTO `blue_user`(`email`, `password`, `token`, `ip`, `time`, `risk`, `money`) VALUES ('$to', '$password', '$token', '$ip', '$time', '0', '0.00')");
                    $bluestar->add_log($conn,"用户注册成功",$to,$ip,$time,"200");//插入日志
                    setcookie("user_email", $to, time()+60*60*24*7);
                    setcookie("user_password", hash("sha256", $_REQUEST["password"]), time()+60*60*24*7);
                    echo json_encode($return);
                }else{
                    $return = array('code'=>502);
                    echo json_encode($return);
                }
            }else{
                $return = array('info'=>"验证码错误", 'code'=>404);
                echo json_encode($return);
            }
        }
        }
    }
?>