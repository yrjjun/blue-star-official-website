<!DOCTYPE html>
<html>

<head>
	<meta charset="UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title><?php echo $config["websitename"] ?></title>
	<link rel="stylesheet" href="./file/css/style.css">
	<script src="./file/js/jq.js"></script>
</head>
<?php
// 处理表单提交
if (isset($_POST['url'])) {
    $url = $_POST['url'];

    // 生成短码
    $shortCode = generateShortCode();

    // 插入数据库
    $sql = "INSERT INTO urls (url, shortcode) VALUES ('$url', '$shortCode')";
    if (mysqli_query($conn,$sql) === TRUE) {
        $shortUrl = $config["websiteurl"] . $shortCode;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// 生成短码函数
function generateShortCode() {
    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $shortCode = '';
    $length = 6;

    for ($i = 0; $i < $length; $i++) {
        $randomIndex = rand(0, strlen($alphabet) - 1);
        $shortCode .= $alphabet[$randomIndex];
    }

    return $shortCode;
}

?>
<body>
	<noscript>
		<style>
			#app {
				display: none;
			}

			body {
				margin: 8px
			}
		</style>
		<b>Please start JavaScript to run this website.</b>
	</noscript>
	<div id="app">
		<header class="app_header">
			<a class="app_header_title" href="?" alt="BlueStarNet">
				<text><?php echo $config["websitename"] ?></text>
			</a>
			<div class="app_header_navigate">
				<?php
				foreach ($bluestar->get_nav($conn) as $nav) {
					$url = $nav["url"];
					$name = $nav["name"];
					echo <<<_
					<a class="app_header_navigate_div" href="$url">$name</a>
					_;
				}
				?>
			</div>
			<div class="app_header_spacer"></div>
			<?php
			if ($user_info == false) {
				echo <<<_
				<a class="app_header_login">登录/注册</a>
				_;
			} else {
				$user_email = $user_info["email"];
				echo <<<_
				<a id="app_header_user" href="./?path=page&page=me">$user_email</a>
				_;
			}
			?>
		</header>
			<div>
            <h1>网址缩短器</h1>
                <form method="post" action="./?path=page&page=short_url">
                    <input type="text" name="url" placeholder="输入长链接" required>
                    <button type="submit">缩短</button>
                </form>
                <?php if (isset($shortUrl)): ?>
                <p>缩短后的网址：<a href="<?php echo $shortUrl; ?>"><?php echo $shortUrl; ?></a></p>
                <?php endif; ?>
			</div>
		
		<footer class="app_footer">
			<p>© <?php
					$d = date("Y");
					if ($d === "2023") {
						echo $d;
					} else {
						echo "2023-" . $d;
					}
					?> StarDreamNet版权所有！！</p>
		</footer>
	</div>
	<?php
	require("./app/page/login.html");
	?>
	<div class="app_msg"></div>

	<script src="./file/js/script.js"></script>
</body>

</html>