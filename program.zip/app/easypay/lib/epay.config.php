<?php
/* *
 * 配置文件
 */

//支付接口地址
$epay_config['apiurl'] = $config["easypay_url"];

//商户ID
$epay_config['pid'] = $config["easypay_pid"];

//商户密钥
$epay_config['key'] = $config["easypay_key"];
