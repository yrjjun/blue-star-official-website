function button(id,status){
    $.get("./?id="+id+"&status="+status, function (data) {
        window.location.href = "./";
    });
}